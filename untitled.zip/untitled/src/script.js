function mostrarMensagem() {
    alert("As festas brasileiras são uma vibrante expressão de como o campo e a cidade se encontram na celebração da alegria, tradição e cultura. Elas revelam a união entre diferentes ritmos e paisagens, compartilhando com todos a beleza da nossa diversidade. Viva a festa, viva a celebração da nossa história e identidade!");
}
